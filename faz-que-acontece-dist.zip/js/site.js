// Faz que Acontece: menu, revelação ao rolar, mapa sob demanda, formulário via WhatsApp e copiar e-mail.
(function () {
  'use strict';
  var reduz = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function iniciar() {
    // Menu do celular
    var btn = document.getElementById('menu-btn');
    var menu = document.getElementById('menu-movel');
    if (btn && menu) {
      var rotulo = btn.querySelector('span');
      var alternar = function (abrir) {
        menu.hidden = !abrir;
        btn.setAttribute('aria-expanded', String(abrir));
        if (rotulo) rotulo.textContent = abrir ? 'Fechar' : 'Menu';
      };
      btn.addEventListener('click', function () { alternar(menu.hidden); });
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) { alternar(false); btn.focus(); } });
      window.addEventListener('resize', function () { if (window.innerWidth > 900 && !menu.hidden) alternar(false); });
    }

    // Revelação suave: só elementos abaixo da dobra; sem JS tudo fica visível
    if (!reduz && 'IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entradas) {
        entradas.forEach(function (en) {
          if (en.isIntersecting) {
            en.target.classList.add('reveal-in');
            en.target.classList.remove('reveal-pre');
            io.unobserve(en.target);
          }
        });
      }, { rootMargin: '0px 0px -8% 0px' });
      document.querySelectorAll('[data-reveal]').forEach(function (el) {
        if (el.getBoundingClientRect().top > window.innerHeight) {
          el.classList.add('reveal-pre');
          io.observe(el);
        }
      });
    }

    // Mapa do Google carregado só quando o visitante pede
    document.querySelectorAll('[data-map-load]').forEach(function (b) {
      b.addEventListener('click', function () {
        var box = b.closest('[data-map-src]');
        if (!box) return;
        var f = document.createElement('iframe');
        f.src = box.getAttribute('data-map-src');
        f.title = box.getAttribute('data-map-title') || 'Mapa';
        f.loading = 'lazy';
        f.referrerPolicy = 'no-referrer-when-downgrade';
        f.setAttribute('allowfullscreen', '');
        box.innerHTML = '';
        box.appendChild(f);
      });
    });

    // Copiar e-mail
    document.querySelectorAll('[data-copy]').forEach(function (b) {
      b.addEventListener('click', function () {
        var texto = b.getAttribute('data-copy');
        var span = b.querySelector('span');
        var ok = function () { if (span) { span.textContent = 'Copiado'; setTimeout(function () { span.textContent = 'Copiar'; }, 2000); } };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(texto).then(ok, function () { selecionar(b); });
        } else { selecionar(b); }
      });
    });
    function selecionar(b) {
      var alvo = b.parentElement && b.parentElement.querySelector('strong');
      if (!alvo) return;
      var r = document.createRange(); r.selectNodeContents(alvo);
      var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
    }

    // Formulário de contato: monta a mensagem e abre o WhatsApp
    var form = document.getElementById('form-contato');
    if (form) {
      var sel = form.querySelector('#f-interesse');
      var pedido = new URLSearchParams(window.location.search).get('interesse');
      if (pedido && sel && sel.querySelector('option[value="' + pedido.replace(/[^a-z-]/g, '') + '"]')) sel.value = pedido;

      var limpar = function (v, max) { return String(v || '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').replace(/\s+\n/g, '\n').trim().slice(0, max); };
      var erro = function (campo, idErro, msg) {
        var f = form.querySelector(campo).closest('.field');
        var e = form.querySelector(idErro);
        if (msg) { f.setAttribute('data-invalid', ''); e.textContent = msg; } else { f.removeAttribute('data-invalid'); e.textContent = ''; }
        return !msg;
      };
      form.addEventListener('submit', function (ev) {
        ev.preventDefault();
        var nome = limpar(form.nome.value, 100);
        var empresa = limpar(form.empresa.value, 100);
        var msg = limpar(form.mensagem.value, 1500);
        var interesse = sel.options[sel.selectedIndex].text;
        var okNome = erro('#f-nome', '#e-nome', nome.length < 2 ? 'Digite seu nome.' : '');
        var okMsg = erro('#f-msg', '#e-msg', msg.length < 5 ? 'Escreva uma mensagem curta para a Faz.' : '');
        if (!okNome) { form.nome.focus(); return; }
        if (!okMsg) { form.mensagem.focus(); return; }
        var texto = 'Olá! Vim pelo site da Faz que Acontece.\n\n' +
          '*Nome:* ' + nome + '\n' +
          (empresa ? '*Empresa:* ' + empresa + '\n' : '') +
          '*Interesse:* ' + interesse + '\n\n' + msg;
        var url = 'https://wa.me/' + form.getAttribute('data-whatsapp') + '?text=' + encodeURIComponent(texto);
        var st = form.querySelector('#f-status');
        var aberto = window.open(url, '_blank');
        if (aberto) { try { aberto.opener = null; } catch (e) {} } else { window.location.href = url; }
        if (st) st.textContent = 'Abrimos o WhatsApp com a sua mensagem. É só tocar em enviar por lá.';
      });
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();
